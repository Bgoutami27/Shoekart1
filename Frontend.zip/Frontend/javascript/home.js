

document.querySelector('.Login').addEventListener('click', () => {
    console.log('Login button clicked!');
    window.location.assign("http://127.0.0.1:5500/login.html");
    const select = document.querySelector('.text');
    
});








